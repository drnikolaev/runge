function A=A(t);
A=zeros(2,2);
A(1,1) = 1;
A(2,2) = 1;
