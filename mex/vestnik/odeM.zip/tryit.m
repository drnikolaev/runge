format long e;
A=zeros(2,2);
Psi=odeM('A', 0, 3.33333, A, 0.1, 1.e-6, 0.3, 1.e-7, 100);
Psi
