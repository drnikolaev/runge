function rp=rpart(t,x)
	global u;
	rp=A(t)*x + B(t,x)*u;
