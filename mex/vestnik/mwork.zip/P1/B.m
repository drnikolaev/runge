function B=B(t,x)
	B=zeros(2,1);
	B(2,1)=1;
   