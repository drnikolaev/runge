function A=A(t)
A=zeros(2,2);
A(1,1)=-atan(t);
A(1,2)=1;
A(2,1)=1;
A(2,2)=-cos(t/10);
   