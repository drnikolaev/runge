function rj=rpartJ(t,x)
global u;
rj=A(t);
