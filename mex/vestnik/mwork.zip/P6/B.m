function B=B(t,x)
	B=zeros(2,2);
	B(2,1)=-1;
   B(2,2)=-x(1);
   