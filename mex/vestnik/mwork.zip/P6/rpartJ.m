function rj=rpartJ(t,x)
	global u;
	rj=A(t);
	rj(2,1)=rj(2,1)-u(2,1);
