function rj=rpartJ(t,x)
rj=A(t);
