function A=A(t)
A=zeros(2,2);
A(1,2)=1;
A(2,1)=-1;
   