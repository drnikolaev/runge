function A=A(t)
A=zeros(3,3);
A(1,1)=1;
A(1,3)=0.1*sin(t);
A(2,1)=1;
A(3,1)=1;
A(3,3)=1+0.1*sin(t);
   