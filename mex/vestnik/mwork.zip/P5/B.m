function B=B(t,x)
	B=zeros(3,1);
	B(1,1)=1;
   