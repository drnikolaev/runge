function B=B(t,x)
B=zeros(2,1);
B(1)=sin(t);
B(2)=cos(sqrt(2)*t);
   