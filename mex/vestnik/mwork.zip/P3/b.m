function B=B(t,x)
B=zeros(2,1);
B(1)=cos(t);
B(2)=sin(t);
   