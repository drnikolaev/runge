function rm=rpartJ(t,x)
	rm=zeros(2,2);
