function rp=rpart(t,x)
	global u;
	rp=B(t,x)*u;
