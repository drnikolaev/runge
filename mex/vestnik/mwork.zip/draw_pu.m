function draw_pu

global Ts;
global Xs;
global Us;
global deltas;
global pr;

n = size (Ts,1);
Zs = zeros (n,1);

figure;
hold off;
plot3(Ts,Xs(1,:),Xs(2,:),'k-','LineWidth', 2);
%plot(Xs(1,:),Xs(2,:),'k-','LineWidth', 2);
grid on;
xlabel('\it t');
ylabel('\it x_1');
zlabel('\it x_2');

figure;
hold off;
plot(Xs(1,:),Xs(2,:),'k-','LineWidth', 2);
grid on;
xlabel('\it x_1');
ylabel('\it x_2');

figure;
hold off;
plot (Ts, Us, '.b', 'LineWidth', 1);
grid on;
xlabel ('\it t');
ylabel ('\it u_{\delta}');

figure;
hold on;
plot(Ts,deltas,'k:','LineWidth', 1);
plot(Ts,-deltas,'k:','LineWidth', 1);
plot(Ts,pr,'g-');
plot(Ts,Xs(1,:),'k-','LineWidth', 2);
plot(Ts,Xs(2,:),'k--','LineWidth', 2);
plot(Ts,Zs,'k:');
xlabel('\it t');
[hLeg,hT] = legend('\it\delta(t,x)', '\it-\delta(t,x)', '\it\omega(t,x)','\it x_1', '\it x_2', 4);
%set(hT,'FontSize', 14);
%hT
%findobj(hT,'Type','text')
%findobj(hT,'Type','line')
%hT
%findobj(hT)
%set(hT(1),'FontSize', 14);
%set(hT(5),'LineWidth', 2);

