function draw_puAB

global Tsg;
global Xs;
global Us;
global deltas;
global pr;
global mU;

n = size (Tsg,1);
Zs = zeros (n,1);

figure;
hold off;
plot (Xs(1,:), Xs(2,:), 'k-', 'LineWidth', 2);
grid on;
xlabel ('\it x_1');
ylabel ('\it x_2');

figure;
hold off;
plot3 (Tsg, Xs(1,:), Xs(2,:), 'k-', 'LineWidth', 2);
%plot (Xs(1,:),Xs(2,:),'k-','LineWidth', 2);
grid on;
xlabel ('\it t');
ylabel ('\it x_1');
zlabel ('\it x_2');

if (mU == 1)
	figure;
	hold off;
	plot (Tsg, Us(1,:), '.b', 'LineWidth', 1);
	grid on;
	xlabel ('\it t');
	ylabel ('\it u_{\delta}');
end
if (mU == 2)
	figure;
	hold off;
	plot3 (Tsg, Us(1,:), Us(2,:), '.b', 'LineWidth', 1);
	grid on;
	xlabel ('\it t');
	ylabel ('\it u^1_{\delta}');
	zlabel ('\it u^2_{\delta}');
end

figure;
hold on;
plot (Tsg, -deltas,'k:','LineWidth', 1);
plot (Tsg, pr,'g-');
plot (Tsg, Xs(1,:),'k-','LineWidth', 2);
plot (Tsg, Xs(2,:),'k--','LineWidth', 2);
plot (Tsg, Zs,'k:');
xlabel('\it t');
legend('\it-\delta(t,x)', '\it c(t,x)','\it x_1', '\it x_2', 4);
