x=[1 0]';
y=odeLaw('right', 'rightJ', 0, 4, x, 0.1, 1.e-6, 0.3, 1.e-7, 100)

