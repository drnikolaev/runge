function r=right(t,x)
	r=zeros(2,1);
	r(1) = 1;
	r(2) = 1;
