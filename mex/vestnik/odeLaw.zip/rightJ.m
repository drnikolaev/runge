function r=rightJ(t,x)
	r=zeros(2,2);
%	r(1) = (t+1)*x(1);
%	r(2) = (t+1)*x(2);
